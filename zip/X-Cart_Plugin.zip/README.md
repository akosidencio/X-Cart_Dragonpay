Dragonpay X-Cart Plugin
=====================

Dragonpay Plugin for X-Cart Shopping Cart software


Supported version
-----------------

X-Cart version 4.6.3


Notes
-----

I am not not responsible for any problems that might arise from the use of this module. 
Use at your own risk. Please backup any critical data before proceeding.


Installations
-------------

- Download this plugin, Extract/Unzip the files. 

- Upload or copy those file and folder into your X-Cart root folder

 
Reminder
-------------
Please use below url for return url

http://www.your-site.com/payment/cc_molpay_process.php

Replace www.your-site.com with your own xcart URL






